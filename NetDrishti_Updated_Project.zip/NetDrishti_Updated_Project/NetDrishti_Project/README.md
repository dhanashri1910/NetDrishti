# NetDrishti – Intelligent Network Diagnosis & Management Platform

NetDrishti is a Flask-based Computer Networks project for building a network topology, monitoring simulated network health, identifying common configuration faults, understanding their causes, testing routes, and reviewing proposed repairs before applying them.

## Main modules

1. **Dashboard** – network health, device counts, active links, alerts, activity and topology overview.
2. **Topology Builder** – add PCs, switches, routers and servers; configure interfaces, IP addresses, subnet masks, VLANs, gateways, DNS, routes and links.
3. **Fault Lab** – inject and detect the supported network fault scenarios, view diagnosis and proposed corrections, and approve or reject repairs.
4. **Routing** – calculate routes using the current topology and compare available path costs.
5. **Subnet / TCP / UDP Tools** – subnet calculations and localhost socket demonstrations.
6. **Network Reports** – create one complete PDF report for the selected saved network. The report includes the overall connection map, device inventory, interface details, IP/mask/VLAN settings, gateways, DNS, routes, services, links and costs, simulated connectivity results, fault diagnosis and repair history.

**Packet Tracer integration has been removed from this version.** The project works using its own topology builder and internal simulator.

> Network health, connectivity, latency, throughput and ping results are simulated by the built-in engine. They are not measurements from physical network equipment.

## Windows setup and run

Open PowerShell in the folder containing `app.py`:

```powershell
python --version
python -m venv venv
.env\Scripts\Activate.ps1
```

If PowerShell blocks script activation:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.env\Scripts\Activate.ps1
```

Install dependencies and start:

```powershell
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python init_db.py
python app.py
```

Open **http://127.0.0.1:5000**.

Stop the server with **Ctrl+C**. To start it again, activate the virtual environment and run `python app.py`.

## First use

1. Register a user or sign in with your existing account.
2. Open **Topology**.
3. Select **Load sample** to load the sample campus topology, or create your own network.
4. Add devices and connections, configure device properties, then click **Save**.
5. Open **Dashboard** to view the network overview.
6. Use **Fault Lab** to test fault detection and human-approved repair.
7. Use **Routing** to calculate paths from the current topology.
8. Open **Reports** and select **Generate complete topology PDF**.

## Complete network report

The report is generated from the network selected in the top navigation and its latest saved topology. It includes:

- Executive summary and counts of devices and links.
- Overall connection map showing each connected device pair, link state and cost.
- Device-by-device inventory with device type and operational state.
- Interface names, IP addresses, subnet masks, VLANs and interface state.
- Default gateways, DNS servers, switch VLANs, routes, server services and DNS records when configured.
- Complete link inventory.
- Simulated connectivity matrix and network health.
- Recorded fault details, diagnoses and human-approved repair history.
- Conclusion and report generation date.

Save the topology on the **Topology** page before generating the report so the PDF reflects your latest changes.

## Demo administrator

For compatibility with the existing project database, the original demo administrator remains:

- Email: `admin@netpulse.lab`
- Password: `Admin@12345`

Change the password before using the application outside a local demonstration. New users can register from the login page.

## Data and database note

The SQLite database path remains `instance/netpulse.db` so an existing local NetPulse database can continue to be used without moving or renaming it. The application branding and generated report names use **NetDrishti**. The project ZIP intentionally does not include a database file; `python init_db.py` creates the database if it does not already exist.

## Project structure

```text
app.py
config.py
init_db.py
backend/
  auth.py
  views.py
  api.py
models/
  __init__.py
engine/
  simulator.py
  faults.py
  routing.py
  subnet.py
  sockets_demo.py
reports.py
templates/
static/
  css/netdrishti.css
  js/
  vendor/
data/
  sample_network.json
  fault_scenarios.json
tests/
```

## Tests

Run:

```powershell
python -m pytest -q
```
